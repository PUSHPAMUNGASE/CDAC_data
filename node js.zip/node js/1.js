console.log("HELLO WORLD!");
//console.log(document)

var xmlhttp = new XMLHttpRequest();
console.log(xmlhttp);
