In node js we have 3 types of modules 
i.build in modules
ii.Custom modules 
iii.Third party module
a.local module-->locally for current folder
b.global module-->for all the application  npm install -g nodemon

build in modules:
i.http
ii.fs(file system)


//dom manipulation can not be done in node 
it is only present in browser


// XMLHttpRequest(); 
is also not present in node


object object req and res object


localhost:9000

//npm node package manager

