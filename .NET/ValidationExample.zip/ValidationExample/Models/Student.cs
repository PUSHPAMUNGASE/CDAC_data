﻿using System.ComponentModel.DataAnnotations;

namespace ValidationExample.Models
{
    public class Student
    {
        [Required(ErrorMessage = "Please Enter Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Name must be between 2 and 100 characters.")]
        public string Name { get; set; }
        [Required(ErrorMessage ="Email is mandatory")]
        [EmailAddress] 
        public string Email { get; set;}
    }
}
